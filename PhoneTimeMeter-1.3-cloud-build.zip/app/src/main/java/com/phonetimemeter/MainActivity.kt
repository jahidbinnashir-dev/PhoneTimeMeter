package com.phonetimemeter

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.phonetimemeter.databinding.ActivityMainBinding
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("PhoneTimeMeter", Context.MODE_PRIVATE)

        binding.btnGrantPermission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        binding.btnSaveTarget.setOnClickListener {
            val hoursText = binding.etTargetHours.text.toString().trim()
            val minutesText = binding.etTargetMinutes.text.toString().trim()

            val hours = hoursText.toIntOrNull() ?: 0
            val minutes = minutesText.toIntOrNull() ?: 0

            if (hours < 0 || minutes < 0 || minutes > 59) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val totalMinutes = hours * 60 + minutes
            prefs.edit().putInt("daily_target_minutes", totalMinutes).apply()
            Toast.makeText(this, "Daily target saved: ${hours}h ${minutes}m", Toast.LENGTH_SHORT).show()
            updateUI()
            PhoneTimeWidget.updateAllWidgets(this)
        }

        updateUI()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun getTodayUsageMinutes(): Long {
        if (!hasUsagePermission()) return -1

        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        val calendar = Calendar.getInstance()
        // Start of today (local time)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startTime = calendar.timeInMillis
        val endTime = System.currentTimeMillis()

        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            startTime,
            endTime
        )

        var totalTime = 0L
        stats?.forEach { stat ->
            totalTime += stat.totalTimeInForeground
        }

        return totalTime / (1000 * 60) // convert to minutes
    }

    private fun updateUI() {
        val hasPermission = hasUsagePermission()
        binding.permissionCard.visibility = if (hasPermission) android.view.View.GONE else android.view.View.VISIBLE

        val usageMinutes = getTodayUsageMinutes()
        if (usageMinutes >= 0) {
            val hours = usageMinutes / 60
            val minutes = usageMinutes % 60
            binding.tvUsage.text = String.format("%d h %02d m", hours, minutes)
        } else {
            binding.tvUsage.text = "-- h -- m"
        }

        val targetMinutes = prefs.getInt("daily_target_minutes", 180) // default 3 hours
        val targetHours = targetMinutes / 60
        val targetMins = targetMinutes % 60
        binding.etTargetHours.setText(targetHours.toString())
        binding.etTargetMinutes.setText(targetMins.toString())
        binding.tvTarget.text = String.format("Target: %d h %02d m", targetHours, targetMins)

        if (usageMinutes >= 0 && targetMinutes > 0) {
            val progress = ((usageMinutes.toFloat() / targetMinutes) * 100).toInt().coerceIn(0, 100)
            binding.progressBar.progress = progress
            binding.tvProgress.text = "$progress%"
        } else {
            binding.progressBar.progress = 0
            binding.tvProgress.text = "0%"
        }
    }
}
