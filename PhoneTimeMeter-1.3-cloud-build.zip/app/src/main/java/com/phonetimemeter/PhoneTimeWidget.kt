package com.phonetimemeter

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

class PhoneTimeWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, PhoneTimeWidget::class.java)
            )
            if (ids.isNotEmpty()) {
                val intent = Intent(context, PhoneTimeWidget::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }

        private fun getTodayUsageMinutes(context: Context): Long {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = appOps.checkOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName
            )
            if (mode != android.app.AppOpsManager.MODE_ALLOWED) return -1

            val usageStatsManager =
                context.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager

            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            val startTime = calendar.timeInMillis
            val endTime = System.currentTimeMillis()

            val stats = usageStatsManager.queryUsageStats(
                android.app.usage.UsageStatsManager.INTERVAL_DAILY,
                startTime,
                endTime
            )

            var totalTime = 0L
            stats?.forEach { totalTime += it.totalTimeInForeground }

            return totalTime / (1000 * 60)
        }

        internal fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_phone_time)

            val usageMinutes = getTodayUsageMinutes(context)
            val text = if (usageMinutes >= 0) {
                val h = usageMinutes / 60
                val m = usageMinutes % 60
                String.format("%d h %02d m", h, m)
            } else {
                "No permission"
            }

            views.setTextViewText(R.id.widget_usage, text)

            val prefs = context.getSharedPreferences("PhoneTimeMeter", Context.MODE_PRIVATE)
            val target = prefs.getInt("daily_target_minutes", 180)
            val targetText = if (target > 0) {
                String.format("Target: %d h %02d m", target / 60, target % 60)
            } else {
                "No target set"
            }
            views.setTextViewText(R.id.widget_target, targetText)

            // Click opens the app
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
