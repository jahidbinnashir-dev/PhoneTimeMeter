# Phone Time Meter v1.3

Simple Android app to track your daily phone usage with a home-screen widget.

## Features
- Daily phone usage calculation (using local calendar day)
- Home-screen widget
- Set daily target
- Clean modern UI
- GitHub Actions cloud build

## How to build the APK (on phone)

1. Create a new **public** GitHub repository named `PhoneTimeMeter`
2. Upload **all files** from this folder (keep the folder structure)
3. Go to **Actions** tab → **Build Android APK** → **Run workflow**
4. Wait 3–6 minutes
5. Download the artifact named `PhoneTimeMeter-debug-apk`
6. Extract it and install `app-debug.apk` on your phone

## First run
After installing, open the app and grant **Usage Access** permission.
Then you can add the widget to your home screen.
